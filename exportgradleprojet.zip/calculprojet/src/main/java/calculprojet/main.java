package calculprojet;

public class main {
    /**
     * @param args the command line arguments
     */
    public double calc(double x ,double y){
        return x + y;
    }
    public static void main(String[] args) {
    }
}
